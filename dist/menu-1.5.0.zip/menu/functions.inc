<?php

/* Reminder: always indent with 4 spaces (no tabs). */
// +---------------------------------------------------------------------------+
// | Menu Plugin 1.3.0-alpha1                                                  |
// +---------------------------------------------------------------------------+
// | functions.inc                                                             |
// |                                                                           |
// | This file does two things: 1) it implements the necessary Geeklog Plugin  |
// | API methods and 2) implements all the common code needed by this plugin.  |
// +---------------------------------------------------------------------------+
// | Copyright (C) 2012-2018 by the following authors:                         |
// |                                                                           |
// | Authors: Ben - ben AT geeklog DOT fr                                      |
// |                                                                           |
// | Based on the original Sitetailor Plugin                                   |
// | Copyright (C) 2008-2011 by the following authors:                        |
// |                                                                           |
// | Mark R. Evans - mark AT glfusion DOT org                                  |
// +---------------------------------------------------------------------------+
// | Created with the Geeklog Plugin Toolkit.                                  |
// +---------------------------------------------------------------------------+
// |                                                                           |
// | This program is free software; you can redistribute it and/or             |
// | modify it under the terms of the GNU General Public License               |
// | as published by the Free Software Foundation; either version 2            |
// | of the License, or (at your option) any later version.                    |
// |                                                                           |
// | This program is distributed in the hope that it will be useful,           |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
// | GNU General Public License for more details.                              |
// |                                                                           |
// | You should have received a copy of the GNU General Public License         |
// | along with this program; if not, write to the Free Software Foundation,   |
// | Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.           |
// |                                                                           |
// +---------------------------------------------------------------------------+

global $_CONF, $_DB_table_prefix, $_TABLES, $_MENU_CONF, $_MENU_DEFAULT;

/**
* @package Menu
*/

if (stripos($_SERVER['PHP_SELF'], basename(__FILE__)) !== false) {
    die ('This file can not be used on its own.');
}

/**
 * Language file include
 */
$plugin_path = $_CONF['path'] . 'plugins/menu/';
require_once $plugin_path . 'storage.php';
require_once $plugin_path . 'presentation.php';
require_once $plugin_path . 'asset_usage.php';
require_once $plugin_path . 'cache_filesystem.php';
require_once $plugin_path . 'cache.php';
$langfile = $plugin_path . 'language/' . $_CONF['language'] . '.php';
$englishLangFile = $plugin_path . 'language/english.php';

// English is the canonical language. Load it first and keep it as the
// per-key fallback when a translation file is incomplete.
require_once $englishLangFile;

$menuEnglishLanguage = array(
    'LANG_MENU_1' => $LANG_MENU_1,
    'LANG_MENU00' => $LANG_MENU00,
    'LANG_MENU01' => $LANG_MENU01,
    'LANG_HC' => $LANG_HC,
    'LANG_HS' => $LANG_HS,
    'LANG_VC' => $LANG_VC,
    'LANG_VS' => $LANG_VS,
    'LANG_MENU_MENU_TYPES' => $LANG_MENU_MENU_TYPES,
    'LANG_MENU_TYPES' => $LANG_MENU_TYPES,
    'LANG_MENU_TARGET' => $LANG_MENU_TARGET,
    'LANG_MENU_GLFUNCTION' => $LANG_MENU_GLFUNCTION,
    'LANG_MENU_GLTYPES' => $LANG_MENU_GLTYPES,
    'LANG_MENU_ADMIN' => $LANG_MENU_ADMIN,
    'LANG_MENU_GLTYPES_HELP' => $LANG_MENU_GLTYPES_HELP,
    'LANG_MENU_GLFUNCTION_HELP' => $LANG_MENU_GLFUNCTION_HELP,
    'LANG_MENU_TYPES_HELP' => $LANG_MENU_TYPES_HELP,
);

$menuEnglishConfigLanguage = array(
    'LANG_configsections' => isset($LANG_configsections['menu']) ? $LANG_configsections['menu'] : array(),
    'LANG_confignames' => isset($LANG_confignames['menu']) ? $LANG_confignames['menu'] : array(),
    'LANG_configsubgroups' => isset($LANG_configsubgroups['menu']) ? $LANG_configsubgroups['menu'] : array(),
    'LANG_tab' => isset($LANG_tab['menu']) ? $LANG_tab['menu'] : array(),
    'LANG_fs' => isset($LANG_fs['menu']) ? $LANG_fs['menu'] : array(),
    'LANG_configselects' => isset($LANG_configselects['menu']) ? $LANG_configselects['menu'] : array(),
);

if ($langfile !== $englishLangFile && file_exists($langfile)) {
    require $langfile;

    foreach ($menuEnglishLanguage as $languageVariable => $englishValues) {
        $translatedValues = isset(${$languageVariable}) && is_array(${$languageVariable})
            ? ${$languageVariable}
            : array();
        ${$languageVariable} = array_replace($englishValues, $translatedValues);
    }

    foreach ($menuEnglishConfigLanguage as $languageVariable => $englishValues) {
        $translatedValues = isset(${$languageVariable}['menu']) && is_array(${$languageVariable}['menu'])
            ? ${$languageVariable}['menu']
            : array();
        ${$languageVariable}['menu'] = array_replace($englishValues, $translatedValues);
    }
}

unset($menuEnglishLanguage, $menuEnglishConfigLanguage);
/**
 * Load Menu configuration into a stable global runtime array.
 *
 * Do not rely on a pre-existing $_MENU_CONF. functions.inc can be included
 * from different Geeklog scopes and older Menu versions may leave a partial
 * array behind. Defaults are always loaded first, then persisted Geeklog
 * configuration wins.
 */
require_once __DIR__ . '/config.php';
// Geeklog may include functions.inc inside its installer function after
// config.php was loaded elsewhere. require_once then does not import local
// variables, so explicitly use the global defaults and rehydrate only when
// an earlier include did not initialize them.
if (!isset($_MENU_DEFAULT) || !is_array($_MENU_DEFAULT)) {
    require __DIR__ . '/config.php';
}
require_once $_CONF['path_system'] . 'classes/config.class.php';

$menu_config = config::get_instance();
$menuStoredConfig = $menu_config->get_config('menu');
if (!is_array($menuStoredConfig)) {
    $menuStoredConfig = array();
}

$_MENU_CONF = array_merge($_MENU_DEFAULT, $menuStoredConfig);

require_once __DIR__ . '/autoinstall.php';
$info = plugin_autoinstall_menu('menu');
if (is_array($info) && isset($info['info']['pi_version'])) {
    $_MENU_CONF['pi_version'] = $info['info']['pi_version'];
}
unset($info, $menuStoredConfig);
/**
 * Menu plugin table(s)
 */
$_TABLES['menu'] = $_DB_table_prefix . 'menu';
$_TABLES['menu_config'] = $_DB_table_prefix . 'menu_config';
$_TABLES['menu_elements']= $_DB_table_prefix . 'menu_elements';


require_once $_CONF['path'] . 'plugins/menu/classes/classMenuElement.php';
require_once $_CONF['path'] . 'plugins/menu/runtime_loader.php';
require_once $_CONF['path'] . 'plugins/menu/services.inc.php';

if (MENU_runtimeConfigEnabled('debug', false)) {
    MENU_debugLog(
        'Debug logging enabled; runtime configuration loaded'
        . ' (legacy_rendering=' . (MENU_runtimeConfigEnabled('legacy_rendering', true) ? '1' : '0')
        . ', cache=' . (MENU_runtimeConfigEnabled('enable_cache', true) ? '1' : '0') . ').'
    );
}

/**
 * Declare Menu's read-only Geeklog Plugin Services as available.
 *
 * PLG_invokeService() requires this plugin API hook before dispatching
 * service_getMenuList_menu() or service_getMenuTree_menu().
 *
 * @return bool
 */
function plugin_wsEnabled_menu()
{
    return true;
}

// +---------------------------------------------------------------------------+
// | Geeklog Plugin API Implementation                                         |
// +---------------------------------------------------------------------------+

/**
 * Resolve a [menu:] autotag argument to a menu ID and canonical menu name.
 *
 * Existing name-based behavior has priority. A strictly numeric argument is
 * treated as an ID only when no menu with that exact name exists.
 *
 * @param string $reference
 * @return array|null Array with id and name, or null when no menu exists.
 */
function MENU_resolveAutotagReference($reference)
{
    global $_TABLES;

    $reference = trim((string) $reference);
    if ($reference === '') {
        return null;
    }

    $referenceSql = MENU_dbEscape($reference);
    $id = (int) DB_getItem($_TABLES['menu'], 'id', 'menu_name="' . $referenceSql . '"');
    if ($id > 0) {
        return array('id' => $id, 'name' => $reference);
    }

    if (ctype_digit($reference)) {
        $id = (int) $reference;
        if ($id > 0) {
            $name = DB_getItem($_TABLES['menu'], 'menu_name', 'id=' . $id);
            if ($name !== '' && $name !== null && $name !== false) {
                return array('id' => $id, 'name' => (string) $name);
            }
        }
    }

    return null;
}

/**
* Implements a [menu:] autotag.
*
* @param    string  $op         operation to perform
* @param    string  $content    item (e.g. story text), including the autotag
* @param    array   $autotag    parameters used in the autotag
* @param    mixed               tag names (for $op='tagname') or formatted content
*
*/
function plugin_autotags_menu($op,$content='',$autotag='') {

    global $Menus, $_TABLES, $_CONF;

    if ($op == 'tagname' ) {
        return array('menu');
    } else if ($op == 'parse') {
        /*
         * Check to see if the menu name has spaces, if so, concatenate into a single parm
         */
        if ( isset($autotag['parm2']) ) {
            $autotag['parm1'] .= ' ' . $autotag['parm2'];
        }
        switch( $autotag['tag'] ) {
            case 'menu' :
                $menu = '';
                $reference = trim($autotag['parm1']);
                $resolved = MENU_resolveAutotagReference($reference);
                if ($resolved !== null) {
                    $id = $resolved['id'];
                    $menuName = $resolved['name'];
                    if (isset($Menus[$id]) && $Menus[$id]['menu_type'] == 1) {
                        $menu = MENU_getMenu($menuName,"gl_menu","gl_menu",'',"parent");
                    } else if (isset($Menus[$id]) && $Menus[$id]['menu_type'] == 2) {
                        $menu = MENU_getMenu($menuName,'st-fmenu','','','','st-f-last');
                    } else if (isset($Menus[$id]) && $Menus[$id]['menu_type'] == 3) {
                        $menu = phpblock_getMenu('',$menuName);
                    } else if (isset($Menus[$id]) && $Menus[$id]['menu_type'] == 4) {
                        $menu = MENU_getMenu($menuName,'st-vmenu','','','');
                    }
                }
                $content = str_replace($autotag['tagstr'],$menu,$content);
                break;
        }
        return $content;
    }
}

function plugin_cclabel_menu()
{
    global $_CONF, $LANG_MENU_1;

    $retval = array();
    if (SEC_hasRights('menu.admin')) {
        $label = (isset($LANG_MENU_1) && is_array($LANG_MENU_1)
            && isset($LANG_MENU_1['plugin_name']))
            ? $LANG_MENU_1['plugin_name'] : 'Menu';
        $retval = array($label,
            $_CONF['site_admin_url'] . '/plugins/menu/index.php',
            plugin_geticon_menu());
    }

    return $retval;
}

function plugin_getadminoption_menu()
{
    global $_CONF, $_TABLES, $LANG_MENU_1;

    if (SEC_hasRights('menu.admin')) {
        $label = (isset($LANG_MENU_1) && is_array($LANG_MENU_1)
            && isset($LANG_MENU_1['plugin_name']))
            ? $LANG_MENU_1['plugin_name'] : 'Menu';
        $totalMenus = (int) DB_getItem($_TABLES['menu'], 'COUNT(*)');
        return array($label,
            $_CONF['site_admin_url'] . '/plugins/menu/index.php', $totalMenus);
    }
}

function plugin_geticon_menu()
{
    global $_CONF;
    return $_CONF['site_admin_url'] . '/plugins/menu/images/menu.png';
}

function plugin_chkVersion_menu()
{
    global $_CONF;

    require_once $_CONF['path'] . 'plugins/menu/autoinstall.php';
    $inst_parms = plugin_autoinstall_menu('menu');

    return $inst_parms['info']['pi_version'];
}

function plugin_upgrade_menu()
{
    global $_CONF, $_TABLES;

    $installed_version = DB_getItem($_TABLES['plugins'], 'pi_version',
                                    "pi_name = 'menu'");
    $code_version = plugin_chkVersion_menu();
    if ($installed_version == $code_version) {
        return true;
    }

    require_once $_CONF['path'] . 'plugins/menu/autoinstall.php';

    if (!plugin_compatible_with_this_version_menu('menu')) {
        return 3002;
    }

    // Move plugin-owned files outside path_data before recording the new
    // plugin version. This operation is non-destructive and idempotent.
    if (!MENU_migrateLegacyData()) {
        COM_errorLog('Menu upgrade: unable to migrate legacy menu_data to ' . MENU_dataDir());
        return false;
    }

    // Keep the public image directory site-specific via path_images.
    if (!is_dir($_CONF['path_images'] . 'menu')) {
        @mkdir($_CONF['path_images'] . 'menu', 0755, true);
    }

    MENU_CACHE_cleanup_plugin('');

    $inst_parms = plugin_autoinstall_menu('menu');
    $pi_gl_version = $inst_parms['info']['pi_gl_version'];

    DB_query("UPDATE {$_TABLES['plugins']} SET pi_version = '$code_version', pi_gl_version = '$pi_gl_version' WHERE pi_name = 'menu'");

    return true;
}

function plugin_autouninstall_menu()
{
    $out = array (
        'tables' => array('menu','menu_config','menu_elements'),
        'groups' => array('Menu Admin'),
        'features' => array('menu.admin'),
        'php_blocks' => array(),
        'vars' => array()
    );

    return $out;
}

/**
 * Publish generated menu CSS to a cacheable public file.
 *
 * The filename contains a content fingerprint, so browsers may cache it for a
 * long time without stale styles after a menu configuration change.
 *
 * @param int $menuId
 * @param string $css
 * @return string Public stylesheet URL, or an empty string when publishing fails.
 */
function MENU_publishCssAsset($menuId, $css)
{
    $menuId = (int) $menuId;
    $css = (string) $css;

    if ($menuId <= 0 || $css === '') {
        return '';
    }

    $baseDir = rtrim(MENU_imageDir(), "/\\");
    $baseUrl = rtrim(MENU_imageUrl(), '/');
    if ($baseDir === '' || $baseUrl === '') {
        return '';
    }

    $cssDir = $baseDir . DIRECTORY_SEPARATOR . 'css' . DIRECTORY_SEPARATOR;
    if (!MENU_ensureDirectory($cssDir)) {
        return '';
    }

    $fingerprint = substr(sha1($css), 0, 12);
    $filename = 'menu-' . $menuId . '-' . $fingerprint . '.css';
    $path = $cssDir . $filename;

    if (!is_file($path)) {
        $written = @file_put_contents($path, $css, LOCK_EX);
        if ($written === false) {
            return '';
        }
    }

    return $baseUrl . '/css/' . $filename;
}

/**
 * Return the HTML used to load generated menu CSS.
 *
 * A public fingerprinted stylesheet is preferred. Inline CSS is retained only
 * as a compatibility fallback for installations where the public image path is
 * not writable.
 *
 * @param int $menuId
 * @param string $css
 * @return string
 */
function MENU_cssAssetMarkup($menuId, $css)
{
    $url = MENU_publishCssAsset($menuId, $css);
    if ($url !== '') {
        return '<link rel="stylesheet" type="text/css" href="'
            . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">' . LB;
    }

    return '<style type="text/css">' . $css . '</style>' . LB;
}

function plugin_getheadercode_menu() {
    global $_CONF, $Menus, $_SCRIPTS;

    $menu_header = '';
    $js = '';
    $needsSlickNav = false;
    $legacyRendering = MENU_runtimeConfigEnabled('legacy_rendering', true);
    $loadLegacyCss = MENU_runtimeConfigEnabled('load_legacy_css', true);
    $loadLegacyJs = MENU_runtimeConfigEnabled('load_legacy_js', true);

    if (!$legacyRendering) {
        MENU_debugLog('Legacy header rendering disabled by configuration.');
        return '';
    }

    if (is_array($Menus)) {
        foreach ($Menus as $menu) {
            if (MENU_menuNeedsLegacyJs($menu['menu_id'])) {
                $needsSlickNav = true;
                break;
            }
        }
    }

    if ($needsSlickNav && $loadLegacyCss) {
        $_SCRIPTS->setCSSFile('menu_slicknav', '/menu/css/slicknav.css');
    }
    if ($needsSlickNav && $loadLegacyJs) {
        $_SCRIPTS->setJavaScriptFile('slicknav', '/menu/js/jquery.slicknav.js');
    }

    $this_dir = basename(dirname($_SERVER['SCRIPT_NAME']));
    if ($this_dir == 'menu') {
        $menu_header .= '<meta http-equiv="cache-control" content="no-cache" />' . LB;
        $menu_header .= '<meta http-equiv="pragma" content="no-cache" />' . LB;
    }

    if (is_array($Menus)) {
        foreach ($Menus AS $menu) {
            if (!MENU_isAssetUsageRegistered($menu['menu_id'])) {
                continue;
            }

            if ($menu['active'] == 1) {
                if (MENU_themeHandlesPresentation(isset($menu['menu_name']) ? $menu['menu_name'] : '')) {
                    continue;
                }

                $cacheInstance = 'menu_css_' . $menu['menu_id'] . '__' . $_CONF['theme']
                    . '__' . MENU_presentationCacheFingerprint();
                $retval = MENU_CACHE_check_instance($cacheInstance, 0);

                $custom_css = MENU_dataDir() . 'css' . DIRECTORY_SEPARATOR
                    . 'gl_menu' . $menu['menu_id'] . '.css';
                if (file_exists($custom_css)) {
                    $custom_ccs_code = LB . file_get_contents($custom_css);
                } else {
                    $custom_ccs_code = '';
                }

                if ($retval) {
                    $css_minify = MENU_compress($retval . $custom_ccs_code);
                    if ($loadLegacyCss) {
                        $menu_header .= LB . MENU_cssAssetMarkup($menu['menu_id'], $css_minify);
                    }
                } else {
                    $ms = new Template($_CONF['path'].'plugins/menu/templates/');
                    $ms->set_var('under',50);
                    $ms->set_var('over',99);
                    switch ($menu['menu_type']) {
                        case 1:
                            $stylefile = 'gl_horizontal-cascading.thtml';
                            break;
                        case 2:
                            $stylefile = 'gl_horizontal-simple.thtml';
                            break;
                        case 3:
                            $stylefile = 'gl_vertical-cascading.thtml';
                            $ms->set_var('under',25);
                            break;
                        case 4:
                            $stylefile = 'gl_vertical-simple.thtml';
                            $ms->set_var('under',25);
                            break;
                        default:
                            $stylefile = 'gl_horizontal-cascading.thtml';
                            break;
                    }
                    $ms->set_file(array('style' => $stylefile));
                    $ms->set_var('menu_id', (int) $menu['menu_id']);
                    $ms->set_var('url1', '');
                    $ms->set_var('url2', '');
                    $ms->set_var('menu_parent_background', '');
                    $colorNames = array(
                        'main_menu_bg_color', 'main_menu_hover_bg_color',
                        'main_menu_text_color', 'main_menu_hover_text_color',
                        'submenu_text_color', 'submenu_hover_text_color',
                        'submenu_background_color', 'submenu_hover_bg_color',
                        'submenu_highlight_color', 'submenu_shadow_color',
                    );
                    if (is_array($menu['config'])) {
                        foreach ($menu['config'] AS $name => $value) {
                            if (in_array($name, $colorNames, true)) {
                                $ms->set_var($name, MENU_cssColor($value));
                                continue;
                            }
                            if ($name === 'menu_bg_filename'
                                || $name === 'menu_hover_filename'
                                || $name === 'menu_parent_filename') {
                                $ms->set_var($name, MENU_cssImageFilename($value));
                                continue;
                            }
                            if ($name === 'use_images') {
                                continue;
                            }
                            if ($name === 'menu_alignment') {
                                $ms->set_var($name, ((int) $value === 1) ? 1 : 0);
                                continue;
                            }
                        }
                        if (isset($menu['config']['use_images']) && (int) $menu['config']['use_images'] === 1) {
                            $ms->set_var('url1', MENU_cssImageBackground(
                                isset($menu['config']['menu_bg_filename']) ? $menu['config']['menu_bg_filename'] : '',
                                'repeat-x'
                            ));
                            $ms->set_var('url2', MENU_cssImageBackground(
                                isset($menu['config']['menu_hover_filename']) ? $menu['config']['menu_hover_filename'] : '',
                                'repeat-x'
                            ));
                            $ms->set_var('menu_parent_background', MENU_cssImageBackground(
                                isset($menu['config']['menu_parent_filename']) ? $menu['config']['menu_parent_filename'] : ''
                            ));
                        }
                    }
                    $menuAlignment = isset($menu['config']['menu_alignment'])
                        ? (int) $menu['config']['menu_alignment']
                        : (((int) $menu['menu_type'] === 2) ? 0 : 1);
                    if ($menuAlignment === 1) {
                        $ms->set_var('alignment','left');
                    } else {
                        $ms->set_var('alignment','right');
                    }

                    $ms->parse('output', 'style');
                    $fCSS = $ms->finish($ms->get_var('output'));

                    if ($menu['menu_type'] == 1 && $loadLegacyJs) {
                        $slicknave_css = " .slicknav_menu { display:none; } @media screen and (max-width: 750px) { #gl_menu" . $menu['menu_id'] . " { display:none; } .slicknav_menu { display:block; } }";
                    } else {
                        $slicknave_css = '';
                    }

                    $fCSS = $fCSS . $slicknave_css;
                    MENU_CACHE_create_instance($cacheInstance, $fCSS, 0);
                    $css_minify = MENU_compress($fCSS . $custom_ccs_code);
                    if ($loadLegacyCss) {
                        $menu_header .= LB . MENU_cssAssetMarkup($menu['menu_id'], $css_minify);
                    }
                }

                if (MENU_menuNeedsLegacyJs($menu['menu_id'])) {
                    $siteName = json_encode((string) $_CONF['site_name']);
                    if ($siteName === false) {
                        $siteName = '"Menu"';
                    }
                    $js .= LB . "jQuery(document).ready(function() {
                        jQuery('#gl_menu" . $menu['menu_id'] . "').slicknav(({
                            label: " . $siteName . ",
                            allowParentLinks: true,
                        }));
                        jQuery( '.slicknav_nav .gl_menu" . $menu['menu_id'] . "' ).removeClass( 'gl_menu" . $menu['menu_id'] . "' );
                    });" . LB;
                }
            }
        }
    }

    if ($needsSlickNav && $loadLegacyJs) {
        $_SCRIPTS->setJavaScriptLibrary('jquery');
        if ($js !== '') {
            $_SCRIPTS->setJavaScript($js, true);
        }
    }

    return $menu_header;
}

function MENU_initMenu($force = false) {
    global $Menus, $_GROUPS;

    $mbadmin = SEC_hasRights('menu.admin');
    $root = SEC_inGroup('Root');
    $Menus = MENU_loadRuntimeMenus($mbadmin, $root, $_GROUPS);
}

function MENU_getMenu($name='navigation',$wrapper='',$ulclass='',$liclass='',$parentclass='',$lastclass='',$selected='',$noid=0) {
    global $Menus, $_CONF;

    if (!MENU_runtimeConfigEnabled('legacy_rendering', true)) {
        MENU_debugLog('Legacy render skipped for menu ' . (string) $name . '.');
        return '';
    }

    $retval = '';
    $menuID = '';
    $lang = COM_getLanguageId();

    if (!empty($lang)) {
        $mlname = $name . '_'.$lang;
        if (is_array($Menus)) {
            foreach ($Menus AS $id) {
                if ($id['menu_name'] == $mlname) {
                    $menuID = $id['menu_id'];
                    break;
                }
            }
        }
    }
    if ($menuID == '') {
        $menuID = '';
        if (is_array($Menus)) {
            foreach ($Menus AS $id) {
                if (strcasecmp(trim($id['menu_name']), trim($name)) == 0) {
                    $menuID = $id['menu_id'];
                    break;
                }
            }
        }
    }
    if ($menuID != '' && $Menus[$menuID]['active'] == 1 && $Menus[$menuID]['menu_perm'] == 3) {
        MENU_registerAssetUsage($menuID);

        if ($Menus[$menuID]['menu_type'] == 1) {
            $retval .= '<div id="gl_menu'.($noid == 0 ? $menuID : '').'"'
                . MENU_legacyNavigationAttributes($name) . '>'. LB;
        }
        if ($wrapper != '') {
            $retval .= '<div class="'.$wrapper.($noid == 0 ? $menuID : '').'">' . LB;
        }
        // Provider-bearing menus use the same permission-filtered composed tree
        // as themes, including Menu-owned entries attached to provider nodes.
        // Plain legacy menus retain their original renderer unchanged.
        $hasProviderMarkers = false;
        foreach ($Menus[$menuID]['elements'] as $menuElement) {
            if ((int) $menuElement->type === 6
                && MENU_providerMarker((string) $menuElement->url) !== null) {
                $hasProviderMarkers = true;
                break;
            }
        }
        if ($hasProviderMarkers) {
            $tree = MENU_getResolvedTree($Menus[$menuID]['menu_name']);
            $retval .= MENU_providerRenderHtml($tree);
        } else {
            $retval .= $Menus[$menuID]['elements'][0]->showTree(0,$ulclass,$liclass,$parentclass,$lastclass,$selected);
        }
        if ($wrapper != '') {
            $retval .= '</div>' . LB;
        }
        if ($Menus[$menuID]['menu_type'] == 1) {
            $retval .= '</div>'. LB;
        }
    } else {
        return '';
    }

    return $retval;
}

function phpblock_getMenu($arg1,$arg2) {
    global $Menus, $_GROUPS, $_CONF;

    $menuID = null;
    if (is_array($Menus)) {
        foreach ($Menus AS $id) {
            if ($id['menu_name'] == $arg2) {
                $menuID = $id['menu_id'];
                break;
            }
        }
    }
    if ($menuID === null || $Menus[$menuID]['active'] != 1 || $Menus[$menuID]['menu_perm'] == 0) {
        return;
    }

    if ($Menus[$menuID]['menu_type'] == 4) {
        $menu = MENU_getMenu($arg2,'st-vmenu','','','');
        return $menu != '' ? $menu : '';
    }
    $menuAlignment = isset($Menus[$menuID]['config']['menu_alignment'])
        ? (int) $Menus[$menuID]['config']['menu_alignment']
        : (((int) $Menus[$menuID]['menu_type'] === 2) ? 0 : 1);
    if ($menuAlignment === 1) {
        $parent = 'parent-l';
        $class  = 'gl_menu-vert-l';
    } else {
        $parent = 'parent-r';
        $class  = 'gl_menu-vert-r';
    }
    $menu = MENU_getMenu($arg2,$class,'','',$parent);
    if ($menu != '') {
        $retval = '<div id="'.$class.$menuID.'">';
        $retval .= $menu;
        $retval .= '</div>';
    } else {
        $retval = '';
    }

    return $retval;
}

function MENU_getImageFile($image) {
    global $_CONF;
    return $_CONF['site_admin_url'] . '/plugins/menu/images/' . $image;
}

function MENU_PLG_getMenuItems()
{
    global $_PLUGINS;

    $menu = array();
    $mbmenu = array();
    foreach ($_PLUGINS as $pi_name) {
        $function = 'plugin_getmenuitems_' . $pi_name;
        if (function_exists($function)) {
            $menuitems = $function();
            if (is_array($menuitems)) {
                $url = current($menuitems);
                $mbmenu[$pi_name] = $url;
                $menu = array_merge($menu, $mbmenu);
            }
        }
    }
    return $menu;
}

MENU_initMenu();

function plugin_templatesetvars_menu($templatename, &$template)
{
    global $_TABLES;

    if (!isset($_TABLES['menu']) || !DB_checkTableExists('menu')) {
        return;
    }

    if ($templatename === 'header') {
        if (MENU_templateUsesVariable('header', $template, 'header_navigation')) {
            $menu = MENU_getMenu('navigation',"gl_menu","gl_menu",'',"parent");
            $template->set_var('header_navigation',$menu);
        }

        if (MENU_templateUsesVariable('footer', $template, 'menu_footer')) {
            if (function_exists('COM_createHTMLDocument')) {
                // Geeklog's modern document renderer uses one index.thtml for the
                // complete page. Set the footer variable now so its assets are
                // known before plugin_getheadercode_menu() runs.
                $menu_footer = MENU_getMenu('footer',"st-fmenu","st-fmenu",'',"parent");
                $template->set_var('menu_footer',$menu_footer);
            } else {
                // Geeklog 2.1.1 renders footer.thtml after the head is finalized.
                // The source check above proves the legacy footer requests this
                // variable, so pre-register only its assets; actual HTML remains
                // rendered by the footer hook below.
                MENU_registerNamedAssetUsage('footer');
            }
        }
    } elseif ($templatename === 'footer'
        && !function_exists('COM_createHTMLDocument')
        && MENU_templateUsesVariable('footer', $template, 'menu_footer')) {
        $menu_footer = MENU_getMenu('footer',"st-fmenu","st-fmenu",'',"parent");
        $template->set_var('menu_footer',$menu_footer);
    }

    $template->set_var('breadcrumbs', '');
}

MENU_ensureDataDirs();
